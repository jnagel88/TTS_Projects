class WelcomeController < ApplicationController
  def about
  end

  def pet_list
  end

  def index
  end
end
