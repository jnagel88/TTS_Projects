require "application_system_test_case"

class PetsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit pets_url
  #
  #   assert_selector "h1", text: "Pet"
  # end
end
