class Activity < ApplicationRecord
end
