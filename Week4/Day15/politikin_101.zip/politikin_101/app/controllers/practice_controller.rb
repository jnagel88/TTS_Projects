class PracticeController < ApplicationController
  def index
  end

  def about
  end
end
